var dir_4905c2a059c126481fe862de1effc122 =
[
    [ "checkingFunctions.c", "checking_functions_8c.html", "checking_functions_8c" ],
    [ "checkingFunctions.h", "checking_functions_8h.html", "checking_functions_8h" ],
    [ "generatePlayfield.c", "generate_playfield_8c.html", "generate_playfield_8c" ],
    [ "generatePlayfield.h", "generate_playfield_8h.html", "generate_playfield_8h" ],
    [ "minesweeper.c", "minesweeper_8c.html", "minesweeper_8c" ],
    [ "minesweeper.h", "minesweeper_8h.html", "minesweeper_8h" ],
    [ "playerInfo.c", "player_info_8c.html", "player_info_8c" ],
    [ "playerInfo.h", "player_info_8h.html", "player_info_8h" ],
    [ "prints.c", "prints_8c.html", "prints_8c" ],
    [ "prints.h", "prints_8h.html", "prints_8h" ],
    [ "revealFields.c", "reveal_fields_8c.html", "reveal_fields_8c" ],
    [ "revealFields.h", "reveal_fields_8h.html", "reveal_fields_8h" ]
];