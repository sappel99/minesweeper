var structmatrix =
[
    [ "hiddenSymbol", "structmatrix.html#af3b1cb28c61bd60cb3122742de48c573", null ],
    [ "index", "structmatrix.html#a750b5d744c39a06bfb13e6eb010e35d0", null ],
    [ "next", "structmatrix.html#a7e7ed282a62db17266824ee9b4fc6643", null ],
    [ "publicSymbol", "structmatrix.html#a610c3c2f7efeef2aabfd90615f9a96d9", null ],
    [ "x", "structmatrix.html#a6150e0515f7202e2fb518f7206ed97dc", null ],
    [ "y", "structmatrix.html#a0a2f84ed7838f07779ae24c5a9086d33", null ]
];