var reveal_fields_8h =
[
    [ "findMoreZeroes", "reveal_fields_8h.html#ab731629d8caf1014dad3db6d8c5b49a5", null ],
    [ "readAndReveal", "reveal_fields_8h.html#a7b47a59db5b7cf559d232e71e40e9988", null ],
    [ "revealAroundXY", "reveal_fields_8h.html#a7e22039bb70308a0489a390bab972a0d", null ],
    [ "turnPublicZeroIntoSpace", "reveal_fields_8h.html#ae603a80c3e2bf170a9ff023cb2bab39b", null ]
];