var generate_playfield_8h =
[
    [ "calculateMineValues", "generate_playfield_8h.html#a8f815b4398b28d63d807edd910bc661a", null ],
    [ "generateMatrix", "generate_playfield_8h.html#adafb083cfed9f1d9ea74a0445fa618eb", null ],
    [ "insertlist", "generate_playfield_8h.html#ae3e6da6cf2fd760f11104997d2ee61a7", null ],
    [ "revealFirst", "generate_playfield_8h.html#a4e462fd7a747d945ebb35273e6fb103e", null ],
    [ "setMines", "generate_playfield_8h.html#acef14dcecd93220ef270bb78be3ba5d2", null ]
];