var player_info_8c =
[
    [ "askPlayerInfo", "player_info_8c.html#a4c252d74b54f8800de4b747fc0a31d7a", null ],
    [ "loadPlayerInfo", "player_info_8c.html#aea86e3a1a9c87a719ef5f7ee5f59265e", null ],
    [ "saveGame", "player_info_8c.html#aef86fd3cd76a83217fd07dfc5860a562", null ],
    [ "savePlayerInfo", "player_info_8c.html#a0ec4485ee4b552f8de8cf3b1dee12893", null ]
];