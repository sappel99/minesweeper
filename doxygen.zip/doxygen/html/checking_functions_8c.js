var checking_functions_8c =
[
    [ "checkAllFieldsOpened", "checking_functions_8c.html#a7d96bf3762dc88a649026c9412b8859f", null ],
    [ "checkAllMinesMarked", "checking_functions_8c.html#a2ac18aa50d957f55b5cbae936dcec0e9", null ],
    [ "checkMainParameters", "checking_functions_8c.html#a033e0bef0eb73824715c58ebea61087b", null ],
    [ "isAlphaSwitch", "checking_functions_8c.html#a97f3fe444eb62bcbd36939a2c8a7e22f", null ],
    [ "isDigit", "checking_functions_8c.html#a815dfc28204b922344916fe04bc9682d", null ],
    [ "isDigitSwitch", "checking_functions_8c.html#a97c5442561c1a0beb953467bc01438a4", null ],
    [ "partOfAlphabet", "checking_functions_8c.html#a412a1045ea1433ad50c9f0865a644c08", null ]
];