var searchData=
[
  ['insertlist_82',['insertlist',['../generate_playfield_8c.html#ae3e6da6cf2fd760f11104997d2ee61a7',1,'insertlist(int x, int y, int index, const char publicSymbol[2], const char hiddenSymbol[2], struct matrix *start):&#160;generatePlayfield.c'],['../generate_playfield_8h.html#ae3e6da6cf2fd760f11104997d2ee61a7',1,'insertlist(int x, int y, int index, const char publicSymbol[2], const char hiddenSymbol[2], struct matrix *start):&#160;generatePlayfield.c']]],
  ['isalphaswitch_83',['isAlphaSwitch',['../checking_functions_8c.html#a97f3fe444eb62bcbd36939a2c8a7e22f',1,'isAlphaSwitch(char alpha):&#160;checkingFunctions.c'],['../checking_functions_8h.html#a60c62964182224f537d88755337ebf19',1,'isAlphaSwitch(char digit):&#160;checkingFunctions.c']]],
  ['isdigit_84',['isDigit',['../checking_functions_8c.html#a815dfc28204b922344916fe04bc9682d',1,'isDigit(char numberIn):&#160;checkingFunctions.c'],['../checking_functions_8h.html#a815dfc28204b922344916fe04bc9682d',1,'isDigit(char numberIn):&#160;checkingFunctions.c']]],
  ['isdigitswitch_85',['isDigitSwitch',['../checking_functions_8c.html#a97c5442561c1a0beb953467bc01438a4',1,'isDigitSwitch(char digit):&#160;checkingFunctions.c'],['../checking_functions_8h.html#a97c5442561c1a0beb953467bc01438a4',1,'isDigitSwitch(char digit):&#160;checkingFunctions.c']]]
];
