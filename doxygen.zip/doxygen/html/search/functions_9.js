var searchData=
[
  ['savegame_97',['saveGame',['../player_info_8c.html#aef86fd3cd76a83217fd07dfc5860a562',1,'saveGame(char spielername[256], struct matrix list):&#160;playerInfo.c'],['../player_info_8h.html#aef86fd3cd76a83217fd07dfc5860a562',1,'saveGame(char spielername[256], struct matrix list):&#160;playerInfo.c']]],
  ['saveplayerinfo_98',['savePlayerInfo',['../player_info_8c.html#a0ec4485ee4b552f8de8cf3b1dee12893',1,'savePlayerInfo(char spielername[256], int playedGames, int gamesWon, int gamesLost, int openedCells):&#160;playerInfo.c'],['../player_info_8h.html#a0ec4485ee4b552f8de8cf3b1dee12893',1,'savePlayerInfo(char spielername[256], int playedGames, int gamesWon, int gamesLost, int openedCells):&#160;playerInfo.c']]],
  ['setmines_99',['setMines',['../generate_playfield_8c.html#acef14dcecd93220ef270bb78be3ba5d2',1,'setMines(struct matrix list, int mines, int rows, int cols, int minesIndex[mines]):&#160;generatePlayfield.c'],['../generate_playfield_8h.html#acef14dcecd93220ef270bb78be3ba5d2',1,'setMines(struct matrix list, int mines, int rows, int cols, int minesIndex[mines]):&#160;generatePlayfield.c']]]
];
