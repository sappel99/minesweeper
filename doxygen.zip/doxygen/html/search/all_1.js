var searchData=
[
  ['calculateminevalues_1',['calculateMineValues',['../generate_playfield_8c.html#a8f815b4398b28d63d807edd910bc661a',1,'calculateMineValues(struct matrix list, int mines, int cols, const int minesIndex[mines]):&#160;generatePlayfield.c'],['../generate_playfield_8h.html#a8f815b4398b28d63d807edd910bc661a',1,'calculateMineValues(struct matrix list, int mines, int cols, const int minesIndex[mines]):&#160;generatePlayfield.c']]],
  ['checkallfieldsopened_2',['checkAllFieldsOpened',['../checking_functions_8c.html#a7d96bf3762dc88a649026c9412b8859f',1,'checkAllFieldsOpened(struct matrix list, int rows, int cols, int mines):&#160;checkingFunctions.c'],['../checking_functions_8h.html#a7d96bf3762dc88a649026c9412b8859f',1,'checkAllFieldsOpened(struct matrix list, int rows, int cols, int mines):&#160;checkingFunctions.c']]],
  ['checkallminesmarked_3',['checkAllMinesMarked',['../checking_functions_8c.html#a2ac18aa50d957f55b5cbae936dcec0e9',1,'checkAllMinesMarked(struct matrix list, int mines):&#160;checkingFunctions.c'],['../checking_functions_8h.html#a2ac18aa50d957f55b5cbae936dcec0e9',1,'checkAllMinesMarked(struct matrix list, int mines):&#160;checkingFunctions.c']]],
  ['checkingfunctions_2ec_4',['checkingFunctions.c',['../checking_functions_8c.html',1,'']]],
  ['checkingfunctions_2eh_5',['checkingFunctions.h',['../checking_functions_8h.html',1,'']]],
  ['checkmainparameters_6',['checkMainParameters',['../checking_functions_8c.html#a033e0bef0eb73824715c58ebea61087b',1,'checkMainParameters(int argc, char *argv[], int *x, int *y, int *mines):&#160;checkingFunctions.c'],['../checking_functions_8h.html#a033e0bef0eb73824715c58ebea61087b',1,'checkMainParameters(int argc, char *argv[], int *x, int *y, int *mines):&#160;checkingFunctions.c']]],
  ['cmake_5fminimum_5frequired_7',['cmake_minimum_required',['../_c_make_lists_8txt.html#a80c1ed4b3030463eb3021a08b7862fb6',1,'CMakeLists.txt']]],
  ['cmakelists_2etxt_8',['CMakeLists.txt',['../_c_make_lists_8txt.html',1,'']]]
];
