var searchData=
[
  ['turnpubliczerointospace_104',['turnPublicZeroIntoSpace',['../reveal_fields_8c.html#ae603a80c3e2bf170a9ff023cb2bab39b',1,'turnPublicZeroIntoSpace(struct matrix list):&#160;revealFields.c'],['../reveal_fields_8h.html#ae603a80c3e2bf170a9ff023cb2bab39b',1,'turnPublicZeroIntoSpace(struct matrix list):&#160;revealFields.c']]]
];
