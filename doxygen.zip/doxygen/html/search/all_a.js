var searchData=
[
  ['randomnumber_43',['randomNumber',['../minesweeper_8c.html#a48f37c08a9b277d9ede8155b5c3634e3',1,'randomNumber(int x, int y):&#160;minesweeper.c'],['../minesweeper_8h.html#a48f37c08a9b277d9ede8155b5c3634e3',1,'randomNumber(int x, int y):&#160;minesweeper.c']]],
  ['readandreveal_44',['readAndReveal',['../reveal_fields_8c.html#a7b47a59db5b7cf559d232e71e40e9988',1,'readAndReveal(struct matrix list, int rows):&#160;revealFields.c'],['../reveal_fields_8h.html#a7b47a59db5b7cf559d232e71e40e9988',1,'readAndReveal(struct matrix list, int rows):&#160;revealFields.c']]],
  ['readme_2emd_45',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['readme_5fdoxy_2emd_46',['README_DOXY.md',['../_r_e_a_d_m_e___d_o_x_y_8md.html',1,'']]],
  ['revealaroundxy_47',['revealAroundXY',['../reveal_fields_8c.html#a7e22039bb70308a0489a390bab972a0d',1,'revealAroundXY(struct matrix list, int xIn, int yIn):&#160;revealFields.c'],['../reveal_fields_8h.html#a7e22039bb70308a0489a390bab972a0d',1,'revealAroundXY(struct matrix list, int xIn, int yIn):&#160;revealFields.c']]],
  ['revealfields_2ec_48',['revealFields.c',['../reveal_fields_8c.html',1,'']]],
  ['revealfields_2eh_49',['revealFields.h',['../reveal_fields_8h.html',1,'']]],
  ['revealfirst_50',['revealFirst',['../generate_playfield_8c.html#a4e462fd7a747d945ebb35273e6fb103e',1,'revealFirst(struct matrix list, int rows, int cols):&#160;generatePlayfield.c'],['../generate_playfield_8h.html#a4e462fd7a747d945ebb35273e6fb103e',1,'revealFirst(struct matrix list, int rows, int cols):&#160;generatePlayfield.c']]]
];
