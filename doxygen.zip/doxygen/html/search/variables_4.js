var searchData=
[
  ['x_109',['x',['../structmatrix.html#a6150e0515f7202e2fb518f7206ed97dc',1,'matrix']]]
];
