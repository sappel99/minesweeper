var searchData=
[
  ['next_107',['next',['../structmatrix.html#a7e7ed282a62db17266824ee9b4fc6643',1,'matrix']]]
];
