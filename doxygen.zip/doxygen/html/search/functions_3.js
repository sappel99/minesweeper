var searchData=
[
  ['generatematrix_77',['generateMatrix',['../generate_playfield_8c.html#a73442ebb9e97541f7c834e8c302fb98c',1,'generateMatrix(int x, int y, int index, char alph, struct matrix *list, int rows, int cols):&#160;generatePlayfield.c'],['../generate_playfield_8h.html#adafb083cfed9f1d9ea74a0445fa618eb',1,'generateMatrix(int x, int y, int count, char alph, struct matrix *list, int rows, int cols):&#160;generatePlayfield.c']]]
];
