var searchData=
[
  ['loadplayerinfo_86',['loadPlayerInfo',['../player_info_8c.html#aea86e3a1a9c87a719ef5f7ee5f59265e',1,'loadPlayerInfo(char spielername[256], int *playedGames, int *gamesWon, int *gamesLost, int *openedCells):&#160;playerInfo.c'],['../player_info_8h.html#aea86e3a1a9c87a719ef5f7ee5f59265e',1,'loadPlayerInfo(char spielername[256], int *playedGames, int *gamesWon, int *gamesLost, int *openedCells):&#160;playerInfo.c']]]
];
