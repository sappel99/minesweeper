var searchData=
[
  ['partofalphabet_88',['partOfAlphabet',['../checking_functions_8c.html#a412a1045ea1433ad50c9f0865a644c08',1,'partOfAlphabet(char letter):&#160;checkingFunctions.c'],['../checking_functions_8h.html#a412a1045ea1433ad50c9f0865a644c08',1,'partOfAlphabet(char letter):&#160;checkingFunctions.c']]],
  ['printerror_89',['printError',['../prints_8c.html#ab8e966b12ad31f254cf679d48520d488',1,'printError(char *text):&#160;prints.c'],['../prints_8h.html#ab8e966b12ad31f254cf679d48520d488',1,'printError(char *text):&#160;prints.c']]],
  ['printhidden_90',['printHidden',['../prints_8c.html#a0c0e42918a62eaa360ef2a550fab106e',1,'printHidden(struct matrix list):&#160;prints.c'],['../prints_8h.html#a0c0e42918a62eaa360ef2a550fab106e',1,'printHidden(struct matrix list):&#160;prints.c']]],
  ['printinfo_91',['printInfo',['../prints_8c.html#a0934dc1a1f500bec39918061ab3650e7',1,'printInfo(char *text):&#160;prints.c'],['../prints_8h.html#a0934dc1a1f500bec39918061ab3650e7',1,'printInfo(char *text):&#160;prints.c']]],
  ['printmineinfo_92',['printMineInfo',['../prints_8c.html#aff976c4877918f9873903a137f262119',1,'printMineInfo(struct matrix list, int mines):&#160;prints.c'],['../prints_8h.html#aff976c4877918f9873903a137f262119',1,'printMineInfo(struct matrix list, int mines):&#160;prints.c']]],
  ['printpublic_93',['printPublic',['../prints_8c.html#a8e1b3018d60540a60d80dc9dd35f1bc9',1,'printPublic(struct matrix list):&#160;prints.c'],['../prints_8h.html#a8e1b3018d60540a60d80dc9dd35f1bc9',1,'printPublic(struct matrix list):&#160;prints.c']]],
  ['printstructure_94',['printStructure',['../prints_8c.html#ac301060d4c3ff211e5a5a451696c16d2',1,'printStructure(struct matrix list):&#160;prints.c'],['../prints_8h.html#ac301060d4c3ff211e5a5a451696c16d2',1,'printStructure(struct matrix list):&#160;prints.c']]],
  ['printwarn_95',['printWarn',['../prints_8c.html#a9da04970f8029c42e00913db85bed270',1,'printWarn(char *text):&#160;prints.c'],['../prints_8h.html#a9da04970f8029c42e00913db85bed270',1,'printWarn(char *text):&#160;prints.c']]],
  ['printzeroinfo_96',['printZeroInfo',['../prints_8c.html#a2d08c9e8bffe26d1120701e3952fa63e',1,'printZeroInfo(struct matrix list, int rows, int cols):&#160;prints.c'],['../prints_8h.html#a2d08c9e8bffe26d1120701e3952fa63e',1,'printZeroInfo(struct matrix list, int rows, int cols):&#160;prints.c']]]
];
