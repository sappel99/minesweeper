var searchData=
[
  ['generatematrix_11',['generateMatrix',['../generate_playfield_8c.html#a73442ebb9e97541f7c834e8c302fb98c',1,'generateMatrix(int x, int y, int index, char alph, struct matrix *list, int rows, int cols):&#160;generatePlayfield.c'],['../generate_playfield_8h.html#adafb083cfed9f1d9ea74a0445fa618eb',1,'generateMatrix(int x, int y, int count, char alph, struct matrix *list, int rows, int cols):&#160;generatePlayfield.c']]],
  ['generateplayfield_2ec_12',['generatePlayfield.c',['../generate_playfield_8c.html',1,'']]],
  ['generateplayfield_2eh_13',['generatePlayfield.h',['../generate_playfield_8h.html',1,'']]]
];
