var searchData=
[
  ['askplayerinfo_69',['askPlayerInfo',['../player_info_8c.html#a4c252d74b54f8800de4b747fc0a31d7a',1,'askPlayerInfo(char eingabe[256]):&#160;playerInfo.c'],['../player_info_8h.html#a4c252d74b54f8800de4b747fc0a31d7a',1,'askPlayerInfo(char eingabe[256]):&#160;playerInfo.c']]]
];
