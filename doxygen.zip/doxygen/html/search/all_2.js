var searchData=
[
  ['findmorezeroes_9',['findMoreZeroes',['../reveal_fields_8c.html#ab731629d8caf1014dad3db6d8c5b49a5',1,'findMoreZeroes(struct matrix list, int rows):&#160;revealFields.c'],['../reveal_fields_8h.html#ab731629d8caf1014dad3db6d8c5b49a5',1,'findMoreZeroes(struct matrix list, int rows):&#160;revealFields.c']]],
  ['free_5flist_10',['free_list',['../minesweeper_8c.html#a5f75e923fd544ee4af222be4b3604839',1,'free_list(struct matrix *start):&#160;minesweeper.c'],['../minesweeper_8h.html#a5f75e923fd544ee4af222be4b3604839',1,'free_list(struct matrix *start):&#160;minesweeper.c']]]
];
