var searchData=
[
  ['next_26',['next',['../structmatrix.html#a7e7ed282a62db17266824ee9b4fc6643',1,'matrix']]]
];
