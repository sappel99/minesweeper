var searchData=
[
  ['next_27',['next',['../structmatrix.html#a7e7ed282a62db17266824ee9b4fc6643',1,'matrix']]],
  ['null_28',['NULL',['../minesweeper_8h.html#a070d2ce7b6bb7e5c05602aa8c308d0c4',1,'minesweeper.h']]]
];
