var searchData=
[
  ['randomnumber_93',['randomNumber',['../minesweeper_8c.html#a48f37c08a9b277d9ede8155b5c3634e3',1,'randomNumber(int x, int y):&#160;minesweeper.c'],['../minesweeper_8h.html#a48f37c08a9b277d9ede8155b5c3634e3',1,'randomNumber(int x, int y):&#160;minesweeper.c']]],
  ['readandreveal_94',['readAndReveal',['../reveal_fields_8c.html#a7b47a59db5b7cf559d232e71e40e9988',1,'readAndReveal(struct matrix list, int rows):&#160;revealFields.c'],['../reveal_fields_8h.html#a7b47a59db5b7cf559d232e71e40e9988',1,'readAndReveal(struct matrix list, int rows):&#160;revealFields.c']]],
  ['revealaroundxy_95',['revealAroundXY',['../reveal_fields_8c.html#a7e22039bb70308a0489a390bab972a0d',1,'revealAroundXY(struct matrix list, int xIn, int yIn):&#160;revealFields.c'],['../reveal_fields_8h.html#a7e22039bb70308a0489a390bab972a0d',1,'revealAroundXY(struct matrix list, int xIn, int yIn):&#160;revealFields.c']]],
  ['revealfirst_96',['revealFirst',['../generate_playfield_8c.html#a4e462fd7a747d945ebb35273e6fb103e',1,'revealFirst(struct matrix list, int rows, int cols):&#160;generatePlayfield.c'],['../generate_playfield_8h.html#a4e462fd7a747d945ebb35273e6fb103e',1,'revealFirst(struct matrix list, int rows, int cols):&#160;generatePlayfield.c']]]
];
